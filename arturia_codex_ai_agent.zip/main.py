
import os
import openai
import requests
import zipfile
import shutil
from github import Github
from datetime import datetime

# Load environment variables
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
GITHUB_TOKEN = os.getenv("GITHUB_TOKEN")
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")
REPO_NAME = "TRIDxNT/arturia-beta"

openai.api_key = OPENAI_API_KEY

SUPER_PROMPT = """
You are an elite AI agent building a perfect 1:1 OSRS replica called Arturia.
Use the latest OSRS cache and RuneLite client.
Base the project on Elvarg but completely upgrade it:
- Full OSRS logic from the OSRS Wiki
- Localhost server
- Zero imperfections
- Combat, bosses, skills, quests, banking, GE with bots, Tutorial Island
- Full travel systems, equipment logic, RuneLite integration
Preserve all custom commands and donator systems from Arturia-PS.
Deliver code to GitHub and send ZIP to Telegram.
"""

def generate_code():
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": "You are a senior OSRS developer using Elvarg to build Arturia."},
            {"role": "user", "content": SUPER_PROMPT}
        ]
    )
    return response['choices'][0]['message']['content']

def save_code_to_zip(code: str, zip_path: str):
    temp_dir = "/tmp/arturia_agent_output"
    os.makedirs(temp_dir, exist_ok=True)
    main_file_path = os.path.join(temp_dir, "README.md")
    with open(main_file_path, "w") as f:
        f.write(code)

    with zipfile.ZipFile(zip_path, 'w') as zipf:
        zipf.write(main_file_path, arcname="README.md")
    shutil.rmtree(temp_dir)

def send_to_telegram(zip_path: str, message: str):
    with open(zip_path, "rb") as f:
        requests.post(
            f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendDocument",
            data={"chat_id": TELEGRAM_CHAT_ID, "caption": message},
            files={"document": f}
        )

def push_to_github(code: str):
    g = Github(GITHUB_TOKEN)
    repo = g.get_repo(REPO_NAME)
    file_path = "PHASE_0_ARTURIA_README.md"
    repo.create_file(file_path, "Add Phase 0 Arturia code", code, branch="main")

if __name__ == "__main__":
    code_output = generate_code()
    zip_file_path = "/tmp/arturia_phase0.zip"
    save_code_to_zip(code_output, zip_file_path)
    send_to_telegram(zip_file_path, "✅ Arturia Phase 0 output delivered.")
    push_to_github(code_output)
